#!/bin/bash

#Ask for the username
read -p "Enter User Name \$" USERNAME

#Ask User to enter comma separated server list at the propmpt
read -p "Enter comma separated list here \$" server_list

#Empty the files ./server_list.txt & ./unabletoconnecthost.txt file
> ./server_list.txt
> ./unabletoconnecthost.txt


#Part 1 -- Remove comma from list and redirect O/P to ./server_list.txt file
for i in $(echo $server_list | sed "s/,/ /g")
do
	echo $i >> ./server_list.txt
done

#Part2 -- check if we can connect to host over ssh, If not remove the host from ssh and list the host in file unabltconnecthost.txt
for i in `cat ./server_list.txt`
do check=`ssh $USERNAME@$i 'whoami'`
	if [ $? != 0 ]; then 
		sed -i '/'$i'/d' server_list.txt && echo $i >> ./unabletoconnecthost.txt
	fi
done

#Part 3 -- Get a single command prompt that to be executed on all the servers.
read -p "Enter command \$" cmd

#Part 4 -- Connect to servers and executed the command entered.
for i in `cat server_list.txt`
do
echo "=================== $i ===================="
ssh -o StrictHostKeyChecking=no $USERNAME@$i  sudo  $cmd
done

