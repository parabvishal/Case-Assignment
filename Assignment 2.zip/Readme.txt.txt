Instructions

Save the file script.sh on server from which you ssh access to all other servers.

give executable permission to script.sh file

chmod +x script.sh

then execute the script with below

./script.sh
