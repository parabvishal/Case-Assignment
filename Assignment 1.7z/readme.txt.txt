save the docker file "dockerfile" in the preferance dir on your docker server.

Execute the below command on docker server to build the image

docker build -t "dockerfile" .